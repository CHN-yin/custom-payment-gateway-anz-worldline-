<?php

// Helper function to replace special characters in a string
function string_replace($string) {
    return str_replace(array('&', '<', '>', '"', "'"), array('&amp;', '&lt;', '&gt;', '&quot;', '&#039;'), $string);
}

// Helper function to filter and sanitize strings
function strFilter2($string) {
    return preg_replace('/[^a-zA-Z0-9\s]/', '', $string);
}

function send_curl_request($url, $param, $method = 'POST', $headers, $retry = 3) {
    
    $retryCount = 0;

    // 检查是否已设置 Content-type 头部
    $hasContentType = false;
    foreach ($headers as $header) {
        if (str_contains($header, 'Content-type:')) {
            $hasContentType = true;
            break;
        }
    }
    // 如果没有设置 Content-type 头部，则添加默认值
    if (!$hasContentType) {
        $headers[] = "Content-type: application/x-www-form-urlencoded";
    }
    
    while ($retryCount < $retry) {
        $ch = curl_init();

        if (strtoupper($method) === 'GET') {
            $url .= '?' . http_build_query($param);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPGET, true);
        } else {
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($param));
        }

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60); // 设置超时时间为60秒
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $res = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            curl_close($ch);
            $retryCount++;
            if ($retryCount >= $retry) {
                return new WP_Error('curl_error', 'Failed to connect to gateway: ' . $url . ', cURL error: ' . $error_msg);
            }
        } else {
            curl_close($ch);
            return $res;
        }
    }
    return new WP_Error('curl_error', 'Failed to connect to gateway after ' . $retry . ' retries.');
}

// 发送 POST 请求
function send_post_request($url, $param, $headers = []) {
    return send_curl_request($url, $param, 'POST', $headers);
}

// 发送 GET 请求
function send_get_request($url, $param, $headers = []) {
    return send_curl_request($url, $param, 'GET', $headers);
}





// AES 加密
function encrypt($data, $key) {
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $encrypted);
}

// AES 解密
function decrypt($data, $key) {
    $data = base64_decode($data);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
}

//是否手机端访问
function is_mobile() {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    $mobile_agents = array(
        'iPhone', 'iPod', 'Android', 'BlackBerry', 'Opera Mini', 'Opera Mobi', 'IEMobile', 'Mobile', 'Windows Phone', 'Kindle', 'Silk', 'PDA', 'webOS'
    );

    foreach ($mobile_agents as $device) {
        if (stripos($user_agent, $device) !== false) {
            return true;
        }
    }

    return false;
}