<?php
class Custom_Gateway_Plugin {
    private static $instance;
    private $gateway_settings;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // 加载插件设置
        $this->gateway_settings = get_option('custom_gateway_settings');

        // 注册设置  不开放独立设置菜单
        // add_action('admin_init', array($this, 'register_settings'));

        //注册自定义CSS/JS
        add_action('wp_enqueue_scripts', array($this, 'custom_gateway_enqueue'));

        //注册AJAX
        add_action('wp_ajax_complete_payment', array($this, 'complete_payment'));
        add_action('wp_ajax_nopriv_complete_payment', array($this, 'complete_payment'));

        // 添加自定义网关
        add_filter('woocommerce_payment_gateways', array($this, 'add_custom_gateway')); 
    }

    //注册自定义CSS/JS
    public function custom_gateway_enqueue()
    {
        if (is_checkout() || is_checkout_pay_page()) {
            // 引入JQuery
            wp_enqueue_script('jquery');

            // 引入 moment.js 和 moment-timezone.js
            wp_enqueue_script('moment-js', '//cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js', array('jquery'), '2.29.1', true);
            wp_enqueue_script('moment-timezone-js', '//cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.34/moment-timezone-with-data.min.js', array('moment-js'), '0.5.34', true);

            // 引入自定义的 CSS
            wp_enqueue_style('custom-gateway-css', PLUGIN_ASSETS_PATH . 'css/custom-gateway.css', array(), '0.6.0');

            // 引入自定义的 JavaScript 文件
            wp_enqueue_script('custom-gateway-js', PLUGIN_ASSETS_PATH . 'js/custom-gateway.js', array('jquery'), '0.6.0', true);

            // 注册自定义的AJAX请求和插件资源路径
            wp_localize_script('custom-gateway-js', 'custom_gateway_params', array(
                'ajax_url' => admin_url('admin-ajax.php'),
            ));
        }
    }

    //完成支付
    public function complete_payment()
    {
        $wc = new WC_Custom_Gateway();
 
        $reslut = $wc->complete_payment($_POST);

        return $reslut;
    }


    // // 注册设置
    // public function register_settings() {
    //     register_setting('custom_gateway_settings_group', 'custom_gateway_settings');

    //     add_settings_section(
    //         'custom_gateway_section',
    //         '网关设置1',
    //         null,
    //         'custom-gateway'
    //     );

    //     add_settings_field(
    //         'title',
    //         '标题',
    //         array($this, 'render_setting_field'),
    //         'custom-gateway',
    //         'custom_gateway_section',
    //         array('id' => 'title', 'type' => 'text')
    //     );

    //     add_settings_field(
    //         'description',
    //         '描述',
    //         array($this, 'render_setting_field'),
    //         'custom-gateway',
    //         'custom_gateway_section',
    //         array('id' => 'description', 'type' => 'textarea')
    //     );

    //     add_settings_field(
    //         'merchant_key',
    //         '商户秘钥',
    //         array($this, 'render_setting_field'),
    //         'custom-gateway',
    //         'custom_gateway_section',
    //         array('id' => 'merchant_key', 'type' => 'text')
    //     );

    //     add_settings_field(
    //         'gateway_url',
    //         '网关地址',
    //         array($this, 'render_setting_field'),
    //         'custom-gateway',
    //         'custom_gateway_section',
    //         array('id' => 'gateway_url', 'type' => 'url')
    //     );
    // }

    // // 渲染设置字段
    // public function render_setting_field($args) {
    //     $id = $args['id'];
    //     $type = $args['type'];
    //     $options = isset($args['options']) ? $args['options'] : array();
    //     $value = isset($this->gateway_settings[$id]) ? $this->gateway_settings[$id] : '';

    //     switch ($type) {
    //         case 'text':
    //         case 'url':
    //             printf('<input type="%s" id="%s" name="custom_gateway_settings[%s]" value="%s" />', $type, $id, $id, esc_attr($value));
    //             break;
    //         case 'textarea':
    //             printf('<textarea id="%s" name="custom_gateway_settings[%s]">%s</textarea>', $id, $id, esc_textarea($value));
    //             break;
    //         case 'checkbox':
    //             foreach ($options as $key => $label) {
    //                 $checked = isset($value[$key]) ? 'checked' : '';
    //                 printf('<label><input type="checkbox" id="%s" name="custom_gateway_settings[%s][%s]" value="1" %s /> %s</label><br />', $id, $id, $key, $checked, $label);
    //             }
    //             break;
    //     }
    // }

    // 添加自定义网关
    public function add_custom_gateway($gateways) {
        $gateways[] = 'WC_Custom_Gateway';
        return $gateways;
    }
}

// 初始化插件
Custom_Gateway_Plugin::get_instance();
