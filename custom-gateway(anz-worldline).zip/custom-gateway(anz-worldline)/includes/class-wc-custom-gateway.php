<?php

class WC_Custom_Gateway extends WC_Payment_Gateway {
    

    public function __construct() {

        $this->id = 'custom_gateway';
        $this->has_fields = true;
        $this->method_title = __('轮询支付网关(ANZ Worldline)', 'woocommerce');
        $this->method_description = __('WooCommerce轮询支付网关(ANZ Worldline)。', 'woocommerce');

        // 初始化表单字段和设置
        $this->init_form_fields();
        $this->init_settings();

        // 定义用户设置
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->merchant_key = $this->get_option('merchant_key');
        $this->gateway_url = $this->get_option('gateway_url');
        $this->payment_methods = $this->get_option('payment_methods');

        // 添加启用/禁用和删除按钮
        $this->enabled = $this->get_option('enabled');
        // 保存用户在woo设置付款界面的输入的配置参数
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }

    // 初始化表单字段
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('启用/禁用', 'woocommerce'),
                'type' => 'checkbox',
                'label' => __('启用轮询支付网关', 'woocommerce'),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => __('标题', 'woocommerce'),
                'type' => 'text',
                'default' => __('轮询支付网关', 'woocommerce')
            ),
            'description' => array(
                'title' => __('描述', 'woocommerce'),
                'type' => 'textarea',
                'default' => __('使用我们的轮询支付网关支付。', 'woocommerce')
            ),
            'merchant_key' => array(
                'title' => __('商户秘钥', 'woocommerce'),
                'type' => 'text',
                'default' => ''
            ),
            'gateway_url' => array(
                'title' => __('网关地址', 'woocommerce'),
                'type' => 'url',
                'default' => ''
            ),
        );
    }

    // 在支付页面显示支付方式选择
    public function payment_fields() {

        $html = '<p>Pay with your card via the ANZ Worldline Payment Gateway service.</p>';

        if(str_contains($_SERVER['REQUEST_URI'], 'order-pay'))
        {

            //先加载选中
            echo '<script>document.getElementById("payment_method_custom_gateway").checked = true; </script>';

            $html = '
                    <style>
						.payment_method_custom_gateway {
                            padding: 0em !important;
                            background-color: rgba(0, 0, 0, 0) !important;
                        }	
                        .custom-gateway-credit-card-form {
                            display: flex;
                            flex-wrap: wrap;
                            flex-direction: column;
                        }
                        .custom-gateway-credit-card-form p {
                            flex: 1 1 20%; /* Adjust the width as needed */
                            display: flex;
                            flex-direction: column;
                        }
                        /* Mobile styles */
                        @media (max-width: 767px) {
                            .custom-gateway-credit-card-form p {
                                flex: 1 1 100%; /* Adjust the width as needed for mobile */
                            }
                        }
						
                        .custom-gateway-credit-card-form label {
                            margin-bottom: 5px;
                        }
                        .custom-gateway-credit-card-form input {
                            padding: 10px;
                            border: 1px solid #ccc;
                            border-radius: 4px !important;
                            width: 100%;
                            margin-bottom: 15px;
                        }

                        .wc_payment_method {
                            display: none;
                        }

                        .payment_method_custom_gateway {
                            display: block;
                        }
                        .custom-gateway-credit-card-form{
                            margin: 20px 0;
                        }
                        .cc-number {
                            text-align: center;
                        }
                        .custom-gateway-credit-card-form span,
                        .cc-content{
                            display: flex;
                            gap: 15px;
                        }
                        .cc-number-header{
                            display: flex;
                            justify-content: space-between;
                        }
                        .cc-number-img{
                            margin-bottom: 5px;
                        }
                        .cc-number-img > img{
                            width: 39px;
                            hidden: 26px;
                        }
                        
                        @media (max-width: 767px) {
                            .custom-gateway-credit-card-form span,
                            .cc-content{
                                gap: 10px;
                            }
                            .cc-content{
                                flex-direction: column;
                            }
                            .custom-gateway-credit-card-form input {
                                margin-bottom: 10px;
                            }
                        }
                    </style>
                    <div class="custom-gateway-credit-card-form">
                        <p>
                            <div class="cc-number-header">
                                <label for="custom-gateway-cc-number-1">'.$this->translate("Card Number").'</label>
                                <span class="cc-number-img">
                                    <img src="/wp-content/plugins/custom-gateway-ANZ/assets/images/visa.gif" alt="visa" />
                                    <img src="/wp-content/plugins/custom-gateway-ANZ/assets/images/eurocard.gif" alt="eurocard" />
                                </span>
                            </div>
                            <span>
                                <input type="text" id="custom-gateway-cc-number-1" maxlength="4" class="cc-number" placeholder="'.$this->translate("Card Number Input Placeholder").'">
                                <input type="text" id="custom-gateway-cc-number-2" maxlength="4" class="cc-number" placeholder="'.$this->translate("Card Number Input Placeholder").'">
                                <input type="text" id="custom-gateway-cc-number-3" maxlength="4" class="cc-number" placeholder="'.$this->translate("Card Number Input Placeholder").'">
                                <input type="text" id="custom-gateway-cc-number-4" maxlength="4" class="cc-number" placeholder="'.$this->translate("Card Number Input Placeholder").'">
                            </span>
                            <input type="hidden" id="custom-gateway-cc-number" name="cc_number">
                        </p>
                        <p>
                            <label for="custom-gateway-cc-name">'.$this->translate("Card Name").'</label>
                            <input type="text" autocomplete="off" placeholder="'.$this->translate("Card Name").'" id="custom-gateway-cc-name" name="cc_name" class="cc-name">
                        </p>
                        <div class="cc-content">
                            <p>
                                <label for="custom-gateway-cc-expiry">'.$this->translate("Card Expiry Date").'</label>
                                <input type="text" autocomplete="cc-exp"  placeholder="'.$this->translate("Card Expiry Date Placeholder").'" id="custom-gateway-cc-expiry" maxlength="5" class="cc-expired">
                            </p>
						    <p>
                                <label for="custom-gateway-cc-cvc">'.$this->translate("Card CVC").'</label>
                                <input type="text" autocomplete="off" placeholder="'.$this->translate("Card CVC Input Placeholder").'" id="custom-gateway-cc-cvc" name="cc_cvc" minlength="3" maxlength="4" class="cc-cvc">
                            </p>
                        </div>
                        <input type="hidden" id="timezone" name="timezone">
                        <input type="hidden" id="custom-gateway-cc-expiry-val" name="cc_expiry">
                        <input type="hidden" id="device_screen_height" name="device_screen_height">
                        <input type="hidden" id="device_screen_width" name="device_screen_width">
                        <input type="hidden" id="device_color_depth" name="device_color_depth">
                        <input type="hidden" id="device_java_enabled" name="device_java_enabled">
                        <input type="hidden" id="device_javascript_enabled" name="device_javascript_enabled">
                    </div>
                    <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/layui-src/dist/css/layui.css">
                    <script src="//code.jquery.com/jquery-3.6.0.min.js" type="text/javascript"></script>
                    <script src="//cdn.jsdelivr.net/npm/layui-src/dist/layui.js" type="text/javascript"></script>
                    <script>
                        $(document).ready(function () {
                            // 卡号处理
                            $(".cc-number").on("input", function () {
                                const nextInput = $(this).next(".cc-number");
                                const prevInput = $(this).prev(".cc-number");
                                if ($(this).val().length === 4 && nextInput.length) nextInput.focus();
                                if ($(this).val().length === 0 && prevInput.length) prevInput.focus();
                            });
                            $(".cc-number").on("input", function () {
                                updateFullCardNumber();
                            });
                            $(".cc-number").on("paste", function (e) {
                                let pasteData = e.originalEvent.clipboardData.getData("text");
                                pasteData = pasteData.replace(/\D/g, "");
                                if (pasteData.length === 16) {
                                    $("#custom-gateway-cc-number-1").val(pasteData.slice(0, 4));
                                    $("#custom-gateway-cc-number-2").val(pasteData.slice(4, 8));
                                    $("#custom-gateway-cc-number-3").val(pasteData.slice(8, 12));
                                    $("#custom-gateway-cc-number-4").val(pasteData.slice(12, 16));
                                    updateFullCardNumber();
                                    e.preventDefault();
                                }
                            });
                            function updateFullCardNumber() {
                                let fullCardNumber = "";
                                $(".cc-number").each(function () {
                                    fullCardNumber += $(this).val();
                                });
                                $("#custom-gateway-cc-number").val(fullCardNumber);
                            }
                            
                            $(".cc-cvc, .cc-expired, .cc-number").on("input", function () {
                                this.value = this.value.replace(/\D/g, "");
                            });
                            
                            // 日期输入框
                            $("#custom-gateway-cc-expiry").on("input", function() {
                                let value = $(this).val().replace(/\D/g, "");
        
                                if (value.length >= 2) {
                                    value = value.slice(0, 2) + "/" + value.slice(2, 4);
                                }
                                $(this).val(value.slice(0, 5));
                                $("#custom-gateway-cc-expiry-val").val(value.replace("/", ""));
                            });
                            
                            const timezoneOffsetInMinutes = new Date().getTimezoneOffset();
                            $("#timezone").val(timezoneOffsetInMinutes);
                            
                            let deviceData = {
                                screenHeight: screen.height,
                                screenWidth: screen.width,
                                colorDepth: screen.colorDepth,
                                javaEnabled: navigator.javaEnabled(),
                                javaScriptEnabled: true
                            };
                            
                            $("#device_screen_height").val(deviceData.screenHeight);
                            $("#device_screen_width").val(deviceData.screenWidth);
                            $("#device_color_depth").val(deviceData.colorDepth);
                            $("#device_java_enabled").val(deviceData.javaEnabled);
                            $("#device_javascript_enabled").val(deviceData.javaScriptEnabled);
                        });
                    </script>
                    <script>
                        /*
                            监听支付状态事件
                        */
                        $(document).ready(function() {
                            // 获取 URL 参数中的 paymentId
                            const urlParams = new URLSearchParams(window.location.search);
                            const paymentId = urlParams.get("paymentId");

                            // 检查 paymentId 是否存在
                            if (paymentId) {
                                let loadIndex = layer.msg("Loading Orders...", {
                                    icon: 16,
                                    shade: 0.6
                                });;
                                let request = sessionStorage.getItem("request");
                                let order_id = sessionStorage.getItem("__id");
                                

                                // 触发 AJAX 请求获取支付状态
                                $.ajax({
                                    url: "' . admin_url("admin-ajax.php") . '",
                                    type: "POST",
                                    data: {
                                        action: "complete_payment",
                                        order_id: order_id,
                                        payment_id: paymentId,
                                        data: request
                                    },
                                    success: function(response) {
                                        const { icon_type, msg, redirect_url="" } = response.data
                                        sessionStorage.removeItem("request");
                                        sessionStorage.removeItem("__id");
                                        layer.close(loadIndex);
                                        return_payment_page(icon_type, msg, redirect_url);
                                    },
                                    error: function(xhr, status, error) {
                                        sessionStorage.removeItem("request");
                                        sessionStorage.removeItem("__id");
                                        layer.close(loadIndex);
                                        console.log("AJAX error:", error);
                                        return_payment_page(0, `AJAX error:${error}`);
                                    }
                                });
                            } else {
                                console.log("No paymentId found in the URL.");
                            }
                            function return_payment_page(icon_type, msg, url=""){
                                layer.alert(msg, {
                                    title: "'.$this->translate("Tips").'",
                                    icon: icon_type,
                                    btn:["'.$this->translate("Confirm").'"],
                                    success: function(layero, index){
                                        layero.find(".layui-layer-close").on("click", function(){
                                            layer.close(index);
                                            window.location.href = url;
                                        });
                                    },
                                    end: function(){
                                        // 弹窗关闭后的回调
                                    }
                                }, function(index){
                                    // 确认按钮的回调
                                    layer.close(index);
                                    window.location.href = url;
                                }); 
                            }
                        });
                    </script>';
        }

        echo $html;
    }
    

    // 处理支付
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);

        //TODO checkout发起的是ajax 必须有数据返回，不能再php中执行html弹窗
        if(!str_contains($_SERVER['REQUEST_URI'], 'order-pay'))
        {
            //购物车下单
            if ($order->get_status() === 'pending') {
                WC()->cart->empty_cart();
            }

            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url()
            );
        }

        // 如果订单已经支付或已取消，直接返回订单页面
        if ($order->get_status() == 'completed' || $order->get_status() == 'cancelled') {
            return array(
                'result' => 'success',
                'redirect' => $this->get_return_url($order)
            );
        }

        // 标记为等待支付（如果订单状态不是“待处理”）
        if ($order->get_status() != 'pending') {
            $order->update_status('on-hold', __('等待支付', 'woocommerce'));
        }

        // 调用自定义的支付请求
        $response = $this->send_payment_request($order_id);

        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            wc_add_notice($error_message, 'error');
            $this->print_log("process payment error: " . $error_message);
            return array('result' => 'failure');
        }

        // 返回空的结果，保持订单页面的状态
        return array(
            'result' => 'success',
            'redirect' => ''
        );
    }

    /**
     * 完成订单
     */
    public function complete_payment($request) {
        //解密
        $data = decrypt($request['data'], $this->merchant_key);
        $data = json_decode($data, true);
        $order = wc_get_order($request['order_id']);
        $paymeta_id = $request['payment_id'];

        //验证订单是否一致
        if($data['order_id'] != $request['order_id'] || !$order){

            $this->print_log("complete payment error: " . $this->translate("Order Not Found"));
            wp_send_json_error([
                'icon_type' => 2,
                'msg' => $this->translate("Order Not Found")
            ]);
            
        }

        //=====请求支付通道
        //请求时间
        $data['request_time'] = time();

        // 加密参数
        $encrypted_param = encrypt(json_encode($data), $this->merchant_key);
        
        $request_data = [
            'payment_id' => $paymeta_id,
            'data' => $encrypted_param
        ];
        // 发送 支付 请求
        $response = send_post_request($data['finish_url'], ['data' => $request_data]);

        $this->print_log("Curl [ " . $data['finish_url'] . "] Result:" . $response);
 
        if ($response === false) {
            wp_send_json_error([
                'icon_type' => 2,
                'msg' => $this->translate("Pay Fail"),
                'redirect_url' => $order->get_checkout_payment_url()
            ]);
        }
        
        $result = json_decode($response, true);
        
        // 检查支付状态
        if ($result['code'] === 0) {
            wp_send_json_error([
                'icon_type' => 2,
                'msg' => $this->translate("Pay Fail"),
                'redirect_url' => $order->get_checkout_payment_url()
            ]);
        }

        // 完成订单支付
        $order->payment_complete();
        wc_reduce_stock_levels($order->get_id());

        // 返回成功的重定向 URL（订单确认页）
        $redirect_url = $this->get_return_url($order);
        wp_send_json_success([
            'icon_type' => 1,
            'msg' => $this->translate("Pay Success"),
            'redirect_url' => $redirect_url // 成功时重定向到订单确认页
        ]);
    }

    // 显示收据页面上的支付按钮
    public function receipt_page($order_id) {
        var_dump($order_id);exit;
    }

    // 发送支付请求
    public function send_payment_request($order_id) {
        $order = wc_get_order($order_id);

        // 检查网关配置
        if (!$this->gateway_url || !$this->merchant_key) {

            $error_message = $this->translate("Payment Config Error");
            return new WP_Error('payment_config_error', $error_message);
        }

        // 准备请求参数
        $param = $this->prepare_request_params($order);

        //验证请求参数
        if(
            !$param['cc_number']                                                            ||
            !$param['cc_name']                                                              ||
            !$param['cc_expiry']                                                            ||
            !$param['cc_cvc']                                                               ||
            strlen($param['cc_expiry'])!== 4                                                ||
            (strlen($param['cc_cvc']) !== 3 && strlen($param['cc_cvc']) !== 4) ){
            $error_message = $this->translate("Credit Card Request Params Error");
            return new WP_Error('payment_param_error', $error_message);
        }
         if (substr($param['cc_number'], 0, 1) === '4') {
             $param['payment_product_id'] = 1;
         } else if(preg_match('/^5[1-5]/', $param['cc_number'])){
             $param['payment_product_id'] = 3;
         } else{
             $error_message = "Unsupported card type";
             return new WP_Error('payment_param_error', $error_message);
         }
         
         // 3ds重定向链接-query值
         $key = $order->get_order_key();
         $param['return_3ds_url'] = "?order_id=$order_id&pay_for_order=true&key=$key";

        //请求时间
        $param['request_time'] = time();

        // 加密参数
        $encrypted_param = encrypt(json_encode($param), $this->merchant_key);

        // 发送请求
        $response = $this->handle_payment_structure($this->gateway_url . "/api/payment/creditCardPay", ['data' => $encrypted_param]);
        
        if($response['code'] == 0){

            return new WP_Error('payment_structure_error', $this->translate("Payment Structure Fail"));
        }

        //请求时间
        $response['request_time'] = time();

        // 加密参数
        $encrypted_param = encrypt(json_encode($response['data']), $this->merchant_key);

        // 发送 Payment 构建 请求 debug
        $response = $this->handle_payment_structure($response['data']['payment_url'], ['data' => $encrypted_param]);
        
        

        if($response['code'] == 0){

            return new WP_Error('payment_structure_error', $this->translate("Payment Structure Fail"));
        }

        //请求时间
        $response['data']['request_time'] = time();

        // 加密参数
        $encrypted_param = encrypt(json_encode($response['data']), $this->merchant_key);

        //构建弹窗
        $this->display_payment_modal($order, $response['data'], $encrypted_param);
    }

    //支付构建
    private function handle_payment_structure($url, $data)
    {

        //设置请求站点URL
        $headers = ["x-host: ". home_url()];

        // 发送 cURL 请求
        $response = send_post_request($url, $data, $headers);

        $this->print_log("Curl [ " . $url . "] Result:" . $response);

        if ($response === false) {

            return ['code' => 0, "msg" => $this->translate("Payment Structure Fail")];
        } else {

            $result =  json_decode($response, true);

            if($result['code'] == 0 || !isset($result['data']['data'])){

                return ['code' => 0, "msg" => $this->translate("Payment Structure Fail"), 'data' => ['error_msg' => $result['msg']]];
            }
            
            //解密
            $decrypted_param = decrypt($result['data']['data'], $this->merchant_key);

            return ['code' => 1, "msg" => "Success", 'data' => json_decode($decrypted_param, true)];
        }
    }

    /**
     * 构建支付iframe：
     */
    private function display_payment_modal($order, $response, $request) {
        
        
        echo '  <style>
                    .layui-layer-iframe{
                        overflow-y: hidden !important;
                    }
                </style>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/layui-src/dist/css/layui.css">
                <script src="//code.jquery.com/jquery-3.6.0.min.js" type="text/javascript"></script>
                <script src="//cdn.jsdelivr.net/npm/layui-src/dist/layui.js" type="text/javascript"></script>
                <script>
                    sessionStorage.setItem("request", "'. $request .'");
                    sessionStorage.setItem("__id", "' . $order->get_id() . '");
                    
                    const paymentId = '.json_encode($response['payment_id']).';
                    const redirectUrl = '.json_encode($response['redirect_url']).';
                    
                    if(redirectUrl != ""){
                        layui.use(["layer"], function(){
                            var layer = layui.layer;
                            layer.confirm("Jump to 3-D Secure", {icon: 4, closeBtn: 0, move: false, title: "Payment request in progress",btn:["Confirm","Cancel"]},
                            function(){
                                window.location.replace(redirectUrl);
                            }, function(){
                                window.location.href = "' . $order->get_checkout_payment_url() . '";
                            });
                        })
                    }else{
                        // 监听支付状态事件
                        $(document).ready(function() {

                            // 检查 paymentId 是否存在
                            if (paymentId) {
                                let loadIndex = layer.msg("Loading Orders...", {
                                    icon: 16,
                                    shade: 0.6
                                });
                                
                                // 触发 AJAX 请求获取支付状态
                                $.ajax({
                                    url: "' . admin_url("admin-ajax.php") . '",
                                    type: "POST",
                                    data: {
                                        action: "complete_payment",
                                        order_id: ' . $order->get_id() . ',
                                        payment_id: paymentId,
                                        data: "'.$request.'"
                                    },
                                    success: function(response) {
                                        const { icon_type, msg, redirect_url="" } = response.data
                                        sessionStorage.removeItem("request");
                                        sessionStorage.removeItem("__id");
                                        layer.close(loadIndex);
                                        return_payment_page(icon_type, msg, redirect_url);
                                    },
                                    error: function(xhr, status, error) {
                                        sessionStorage.removeItem("request");
                                        sessionStorage.removeItem("__id");
                                        layer.close(loadIndex);
                                        console.log("AJAX error:", error);
                                        return_payment_page(2, `AJAX error:${error}`);
                                    }
                                });
                            } else {
                                console.log("No paymentId.");
                            }
                            function return_payment_page(icon_type, msg, url=""){
                                layer.alert(msg, {
                                    title: "'.$this->translate("Tips").'",
                                    icon: icon_type,
                                    btn:["'.$this->translate("Confirm").'"],
                                    success: function(layero, index){
                                        layero.find(".layui-layer-close").on("click", function(){
                                            layer.close(index);
                                            window.location.href = url;
                                        });
                                    },
                                    end: function(){
                                        // 弹窗关闭后的回调
                                    }
                                }, function(index){
                                    // 确认按钮的回调
                                    layer.close(index);
                                    window.location.href = url;
                                }); 
                            }
                        });
                    }
                </script>';
        exit;
    }

    // 准备请求参数
    private function prepare_request_params($order) {

        $param = array(
            'shopping_site' => home_url(),
            'order_id' => $order->get_id(),
            'payment_method' => $order->get_payment_method(),
            'order_status' => $this->get_order_status($order->get_status()),
            'currency_code' => strtoupper(get_woocommerce_currency()),
            'total_amount' => $order->get_total() * 100,
            'ip' => filter_var($order->get_customer_ip_address(), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ?: '127.0.0.1',
            'locale' => get_locale(),
            'platform_type' => 'woo',
            'create_time' => $order->get_date_created()->getTimestamp(),
            'accept_header' => $_SERVER['HTTP_ACCEPT'],
            'user_agent' => $order->get_customer_user_agent(),
            'goods_info' => $this->get_goodsname($order),
            'username' => $order->get_formatted_billing_full_name(),
            'email' => $order->get_billing_email(),
            'phone' => $order->get_billing_phone(),
            'address' => $this->get_address($order),
            'postcode' => $order->get_billing_postcode(),
            'note' => $order->get_customer_note(),
            'timezone' => sanitize_text_field($_POST['timezone']),
            'cc_name' => sanitize_text_field($_POST['cc_name']),
            'cc_number' => sanitize_text_field($_POST['cc_number']),
            'cc_expiry' => sanitize_text_field($_POST['cc_expiry']),
            'cc_cvc' => sanitize_text_field($_POST['cc_cvc']),
            'device_screen_height' => sanitize_text_field($_POST['device_screen_height']),
            'device_screen_width' => sanitize_text_field($_POST['device_screen_width']),
            'device_color_depth' => (int)sanitize_text_field($_POST['device_color_depth']),
            'device_java_enabled' => (bool)sanitize_text_field($_POST['device_java_enabled']),
            'device_javascript_enabled' => (bool)sanitize_text_field($_POST['device_javascript_enabled'])
        );
        return $param;
    }


    // 获取订单状态
    private function get_order_status($status) {
        $statusMap = [
            'pending'    => 1, // 1: 待支付
            'processing' => 2, // 2: 处理中
            'on-hold'    => 3, // 3: 等待中
            'completed'  => 4, // 4: 已完成
            'cancelled'  => 5, // 5: 已取消
            'refunded'   => 6, // 6: 已退款
            'failed'     => 7, // 7: 失败
        ];

        return isset($statusMap[$status]) ? $statusMap[$status] : 0; // 默认返回 0 表示未知状态
    }

    // 获取订单地址
    private function get_address($order) {
        $country = $order->get_shipping_country() ? $order->get_shipping_country() : $order->get_billing_country();
        $state = $order->get_shipping_state() ? $order->get_shipping_state() : $order->get_billing_state();
        $city = $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city();
        $address_1 = $order->get_shipping_address_1() ? $order->get_shipping_address_1() : $order->get_billing_address_1();
        $address_2 = $order->get_shipping_address_2() ? $order->get_shipping_address_2() : $order->get_billing_address_2();
        $postcode = $order->get_shipping_postcode() ? $order->get_shipping_postcode() : $order->get_billing_postcode();

        $address = array_filter([$country, $state, $city, $address_1, $address_2, $postcode]);
        return implode(", ", $address);
    }

    // 获取订单商品信息
    private function get_goodsname($order) {
        $items = $order->get_items();
        $goodsname = [];

        foreach ($items as $item) {
            if ($item instanceof WC_Order_Item_Product) {
                $product = $item->get_product();
                $goodsname[] = [
                    'price' => number_format($product->get_price(), 2, '.', ''),
                    'name' => strFilter2(string_replace($product->get_name())),
                    'attributes' => strFilter2(string_replace(wc_display_item_meta($item, array('echo' => false, 'autop' => false)))),
                    'quantity' => $item->get_quantity(),
                ];
            }
        }

        return $goodsname;
    }

    // 日志记录错误
    private function print_log($message) {
        $logger = new WC_Logger();
        $logger->add('custom_gateway', $message);
    }

    // 获取翻译值
    private function translate($key) {
        $translations = $GLOBALS['translations'];
        //$current_language = get_locale(); // 获取当前语言，假设使用 WordPress 的 get_locale 函数
        $current_language = LANG;
        if (isset($translations[$current_language]) && isset($translations[$current_language][$key])) {
            return $translations[$current_language][$key];
        }
        return $key; // 如果没有找到翻译，返回 key 作为默认值
    }

}