<?php
/**
 * Plugin Name: 轮询支付网关(anz-worldline)
 * Plugin URI: https://github.com/CHN-yin/custom-payment-gateway(anz-worldline)
 * Description: 为 WooCommerce 提供 ANZ Worldline 支付网关服务。
 * Version: 1.0.0
 * Author: CHN-yin
 */

if (!defined('ABSPATH')) {
    exit; // 防止直接访问
}

define("LANG",  "en");

define("PLUGIN_ASSETS_PATH",  plugin_dir_url(__FILE__) . 'assets/');

// 自动加载类文件
function custom_gateway_autoload($class_name) {
    if (strpos($class_name, 'Custom_Gateway') !== false) {
        require_once plugin_dir_path(__FILE__) . 'includes/class-' . strtolower(str_replace('_', '-', $class_name)) . '.php';
    }
}
spl_autoload_register('custom_gateway_autoload');

// 引入通用函数
require_once plugin_dir_path(__FILE__) . 'includes/utils.php';

//引入语言包
$GLOBALS['translations'] = require_once plugin_dir_path(__FILE__) . 'includes/lang.php';

// 初始化插件
add_action('plugins_loaded', array('Custom_Gateway_Plugin', 'get_instance'));

// 添加设置链接
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'custom_gateway_plugin_action_links');
function custom_gateway_plugin_action_links($links) {
    $settings_link = '<a href="admin.php?page=wc-settings&tab=checkout&section=custom_gateway">' . __('设置') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}